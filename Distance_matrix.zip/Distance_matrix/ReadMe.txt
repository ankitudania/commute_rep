1) Create a python virtual environment
2) Install the requirements using -> pip install -r Requirements.txt
3) Log into Google Cloud Platform and generate API key for Googlemaps API and replace it in the app.py
4) Run the app using -> streamlit run app.py

Add config file for api key, Commands to create env, activate and convert it to exe file